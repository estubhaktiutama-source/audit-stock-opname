import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/stock_opname.dart';
import '../models/material_item.dart';

class DatabaseService {
  DatabaseService._();
  static final DatabaseService instance = DatabaseService._();
  Database? _db;

  Future<Database> get database async {
    if (_db != null) return _db!;
    final path = join(await getDatabasesPath(), 'audit_stock_opname.db');
    _db = await openDatabase(path, version: 1, onCreate: (db, version) async {
      await db.execute('''
        CREATE TABLE opnames(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          activity_name TEXT NOT NULL,
          location TEXT,
          sloc TEXT,
          date TEXT,
          auditor TEXT
        )
      ''');
      await db.execute('''
        CREATE TABLE materials(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          opname_id INTEGER NOT NULL,
          material_number TEXT NOT NULL,
          material_name TEXT,
          unrestricted_stock REAL,
          unit TEXT,
          document_not_gi REAL DEFAULT 0,
          physical_stock REAL DEFAULT 0,
          note TEXT,
          checked INTEGER DEFAULT 0
        )
      ''');
    });
    return _db!;
  }

  Future<int> createOpname(StockOpname item) async {
    final db = await database;
    return db.insert('opnames', item.toMap());
  }

  Future<List<StockOpname>> getOpnames() async {
    final db = await database;
    final rows = await db.query('opnames', orderBy: 'id DESC');
    return rows.map(StockOpname.fromMap).toList();
  }

  Future<int> insertMaterial(MaterialItem item) async {
    final db = await database;
    return db.insert('materials', item.toMap());
  }

  Future<List<MaterialItem>> getMaterials(int opnameId) async {
    final db = await database;
    final rows = await db.query('materials',
        where: 'opname_id = ?', whereArgs: [opnameId], orderBy: 'material_number');
    return rows.map(MaterialItem.fromMap).toList();
  }

  Future<void> updateMaterial(MaterialItem item) async {
    final db = await database;
    await db.update('materials', item.toMap(), where: 'id = ?', whereArgs: [item.id]);
  }
}
