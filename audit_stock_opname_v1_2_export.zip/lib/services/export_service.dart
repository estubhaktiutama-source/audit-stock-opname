import 'dart:io';
import 'package:excel/excel.dart';
import 'package:csv/csv.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import '../models/stock_opname.dart';
import '../models/material_item.dart';

class ExportService {
  String _safe(String value) =>
      value.replaceAll(RegExp(r'[^A-Za-z0-9_-]'), '_');

  Future<File> exportExcel(
      StockOpname opname, List<MaterialItem> items) async {
    final excel = Excel.createExcel();
    final sheet = excel['Hasil Opname'];
    excel.delete('Sheet1');

    sheet.appendRow([TextCellValue('AUDIT STOCK OPNAME')]);
    sheet.appendRow([TextCellValue('Nama Kegiatan'), TextCellValue(opname.activityName)]);
    sheet.appendRow([TextCellValue('Lokasi'), TextCellValue(opname.location)]);
    sheet.appendRow([TextCellValue('Storage Location'), TextCellValue(opname.sloc)]);
    sheet.appendRow([TextCellValue('Tanggal'), TextCellValue(opname.date)]);
    sheet.appendRow([TextCellValue('Auditor'), TextCellValue(opname.auditor)]);
    sheet.appendRow([]);

    final headers = [
      'No',
      'Nomor Material',
      'Material',
      'Unrestricted Stock',
      'Unit',
      'Dokumen Belum GI',
      'Expected Stock',
      'Stok Fisik',
      'Selisih',
      'Status',
      'Keterangan'
    ];
    sheet.appendRow(headers.map((x) => TextCellValue(x)).toList());

    for (var i = 0; i < items.length; i++) {
      final x = items[i];
      final status = !x.checked
          ? 'Belum Diperiksa'
          : x.difference == 0
              ? 'Sesuai'
              : x.difference > 0
                  ? 'Selisih Plus'
                  : 'Selisih Minus';

      sheet.appendRow([
        IntCellValue(i + 1),
        TextCellValue(x.materialNumber),
        TextCellValue(x.materialName),
        DoubleCellValue(x.unrestrictedStock),
        TextCellValue(x.unit),
        DoubleCellValue(x.documentNotGI),
        DoubleCellValue(x.expectedStock),
        DoubleCellValue(x.physicalStock),
        DoubleCellValue(x.difference),
        TextCellValue(status),
        TextCellValue(x.note),
      ]);
    }

    final checked = items.where((x) => x.checked).toList();
    final sesuai = checked.where((x) => x.difference == 0).length;
    final plus = checked.where((x) => x.difference > 0).length;
    final minus = checked.where((x) => x.difference < 0).length;

    sheet.appendRow([]);
    sheet.appendRow([TextCellValue('RINGKASAN')]);
    sheet.appendRow([TextCellValue('Total Material'), IntCellValue(items.length)]);
    sheet.appendRow([TextCellValue('Sudah Diperiksa'), IntCellValue(checked.length)]);
    sheet.appendRow([TextCellValue('Sesuai'), IntCellValue(sesuai)]);
    sheet.appendRow([TextCellValue('Selisih Plus'), IntCellValue(plus)]);
    sheet.appendRow([TextCellValue('Selisih Minus'), IntCellValue(minus)]);

    final bytes = excel.encode();
    final dir = await getApplicationDocumentsDirectory();
    final file = File('${dir.path}/Audit_Stock_Opname_${_safe(opname.activityName)}_${opname.date}.xlsx');
    await file.writeAsBytes(bytes!, flush: true);
    return file;
  }

  Future<File> exportCsv(
      StockOpname opname, List<MaterialItem> items) async {
    final rows = <List<dynamic>>[
      ['AUDIT STOCK OPNAME'],
      ['Nama Kegiatan', opname.activityName],
      ['Lokasi', opname.location],
      ['Storage Location', opname.sloc],
      ['Tanggal', opname.date],
      ['Auditor', opname.auditor],
      [],
      [
        'No',
        'Nomor Material',
        'Material',
        'Unrestricted Stock',
        'Unit',
        'Dokumen Belum GI',
        'Expected Stock',
        'Stok Fisik',
        'Selisih',
        'Status',
        'Keterangan'
      ]
    ];

    for (var i = 0; i < items.length; i++) {
      final x = items[i];
      final status = !x.checked
          ? 'Belum Diperiksa'
          : x.difference == 0
              ? 'Sesuai'
              : x.difference > 0
                  ? 'Selisih Plus'
                  : 'Selisih Minus';
      rows.add([
        i + 1,
        x.materialNumber,
        x.materialName,
        x.unrestrictedStock,
        x.unit,
        x.documentNotGI,
        x.expectedStock,
        x.physicalStock,
        x.difference,
        status,
        x.note
      ]);
    }

    final csv = const ListToCsvConverter().convert(rows);
    final dir = await getApplicationDocumentsDirectory();
    final file = File('${dir.path}/Audit_Stock_Opname_${_safe(opname.activityName)}_${opname.date}.csv');
    await file.writeAsString(csv, flush: true);
    return file;
  }

  Future<void> shareFile(File file, String text) async {
    await Share.shareXFiles([XFile(file.path)], text: text);
  }
}
