import 'dart:io';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import '../models/material_item.dart';

class OcrService {
  Future<String> extractText(File image) async {
    final input = InputImage.fromFile(image);
    final recognizer = TextRecognizer(script: TextRecognitionScript.latin);
    try {
      final result = await recognizer.processImage(input);
      return result.text;
    } finally {
      await recognizer.close();
    }
  }

  // Parser generik V1. Hasil OCR selalu dapat diverifikasi/edit.
  List<MaterialItem> parseMb52(String text) {
    final lines = text.split('\n')
        .map((e) => e.trim())
        .where((e) => e.isNotEmpty)
        .toList();

    final items = <MaterialItem>[];
    final materialRegex = RegExp(r'^\d{4,18}$');
    final numberRegex = RegExp(r'[-+]?\d[\d.,]*');

    for (int i = 0; i < lines.length; i++) {
      if (!materialRegex.hasMatch(lines[i])) continue;

      final material = lines[i];
      double? stock;
      String unit = '';

      for (int j = i + 1; j < lines.length && j <= i + 5; j++) {
        final n = numberRegex.firstMatch(lines[j]);
        if (stock == null && n != null) {
          final raw = n.group(0)!.replaceAll('.', '').replaceAll(',', '.');
          stock = double.tryParse(raw);
          continue;
        }
        if (stock != null && RegExp(r'^[A-Za-z]{1,6}$').hasMatch(lines[j])) {
          unit = lines[j];
          break;
        }
      }

      if (stock != null && unit.isNotEmpty) {
        items.add(MaterialItem(
          materialNumber: material,
          unrestrictedStock: stock,
          unit: unit,
        ));
      }
    }
    return items;
  }
}
