class MaterialItem {
  int? id;
  int? opnameId;
  String materialNumber;
  String materialName;
  double unrestrictedStock;
  String unit;
  double documentNotGI;
  double physicalStock;
  String note;
  bool checked;

  MaterialItem({
    this.id,
    this.opnameId,
    required this.materialNumber,
    this.materialName = '',
    required this.unrestrictedStock,
    required this.unit,
    this.documentNotGI = 0,
    this.physicalStock = 0,
    this.note = '',
    this.checked = false,
  });

  double get expectedStock => unrestrictedStock - documentNotGI;
  double get difference => physicalStock - expectedStock;

  Map<String, dynamic> toMap() => {
    'id': id,
    'opname_id': opnameId,
    'material_number': materialNumber,
    'material_name': materialName,
    'unrestricted_stock': unrestrictedStock,
    'unit': unit,
    'document_not_gi': documentNotGI,
    'physical_stock': physicalStock,
    'note': note,
    'checked': checked ? 1 : 0,
  };

  factory MaterialItem.fromMap(Map<String, dynamic> map) => MaterialItem(
    id: map['id'],
    opnameId: map['opname_id'],
    materialNumber: map['material_number'],
    materialName: map['material_name'] ?? '',
    unrestrictedStock: (map['unrestricted_stock'] as num).toDouble(),
    unit: map['unit'],
    documentNotGI: (map['document_not_gi'] as num).toDouble(),
    physicalStock: (map['physical_stock'] as num).toDouble(),
    note: map['note'] ?? '',
    checked: map['checked'] == 1,
  );
}
