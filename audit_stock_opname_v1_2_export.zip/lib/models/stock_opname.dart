class StockOpname {
  int? id;
  String activityName;
  String location;
  String sloc;
  String date;
  String auditor;

  StockOpname({
    this.id,
    required this.activityName,
    required this.location,
    required this.sloc,
    required this.date,
    required this.auditor,
  });

  Map<String, dynamic> toMap() => {
    'id': id,
    'activity_name': activityName,
    'location': location,
    'sloc': sloc,
    'date': date,
    'auditor': auditor,
  };

  factory StockOpname.fromMap(Map<String, dynamic> map) => StockOpname(
    id: map['id'],
    activityName: map['activity_name'],
    location: map['location'],
    sloc: map['sloc'],
    date: map['date'],
    auditor: map['auditor'],
  );
}
