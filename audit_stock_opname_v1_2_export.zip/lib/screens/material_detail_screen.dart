import 'package:flutter/material.dart';
import '../models/material_item.dart';
import '../services/database_service.dart';

class MaterialDetailScreen extends StatefulWidget {
  final MaterialItem item;
  const MaterialDetailScreen({super.key, required this.item});
  @override
  State<MaterialDetailScreen> createState() => _MaterialDetailScreenState();
}

class _MaterialDetailScreenState extends State<MaterialDetailScreen> {
  late TextEditingController notGI;
  late TextEditingController physical;
  late TextEditingController note;

  @override
  void initState() {
    super.initState();
    notGI = TextEditingController(text: widget.item.documentNotGI == 0 ? '' : widget.item.documentNotGI.toString());
    physical = TextEditingController(text: widget.item.checked ? widget.item.physicalStock.toString() : '');
    note = TextEditingController(text: widget.item.note);
  }

  double? parseValue(String v) {
    if (v.trim().isEmpty) return 0;
    return double.tryParse(v.trim().replaceAll(',', '.'));
  }

  @override
  Widget build(BuildContext context) {
    final item = widget.item;
    final notGiValue = parseValue(notGI.text) ?? 0;
    final physicalValue = parseValue(physical.text) ?? 0;
    final expected = item.unrestrictedStock - notGiValue;
    final diff = physicalValue - expected;

    return Scaffold(
      appBar: AppBar(title: Text('Material ${item.materialNumber}')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Card(child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('DATA MB52', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text('Nomor Material: ${item.materialNumber}'),
            Text('Unrestricted Stock: ${item.unrestrictedStock} ${item.unit}'),
          ]),
        )),
        const SizedBox(height: 16),
        TextField(
          controller: notGI,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: InputDecoration(
            labelText: 'Dokumen Belum GI (${item.unit})',
            helperText: 'Nilai ini selalu mengurangi stok MB52',
            border: const OutlineInputBorder(),
          ),
          onChanged: (_) => setState(() {}),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: physical,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: InputDecoration(
            labelText: 'Stok Fisik (${item.unit})',
            border: const OutlineInputBorder(),
          ),
          onChanged: (_) => setState(() {}),
        ),
        const SizedBox(height: 12),
        Card(child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(children: [
            Text('Expected Stock: $expected ${item.unit}'),
            const SizedBox(height: 8),
            Text(
              'Selisih: ${diff >= 0 ? '+' : ''}$diff ${item.unit}',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: diff == 0 ? Colors.green : diff < 0 ? Colors.red : Colors.orange,
              ),
            ),
          ]),
        )),
        const SizedBox(height: 12),
        TextField(
          controller: note,
          maxLines: 3,
          decoration: const InputDecoration(
            labelText: 'Keterangan Audit',
            border: OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 20),
        FilledButton(
          onPressed: () async {
            final doc = parseValue(notGI.text);
            final phys = parseValue(physical.text);
            if (doc == null || doc < 0) {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Dokumen Belum GI harus berupa angka ≥ 0.')),
              );
              return;
            }
            if (phys == null || phys < 0) {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Stok fisik harus berupa angka ≥ 0.')),
              );
              return;
            }
            if (doc > item.unrestrictedStock) {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Dokumen Belum GI tidak boleh melebihi Unrestricted Stock.')),
              );
              return;
            }
            item.documentNotGI = doc;
            item.physicalStock = phys;
            item.note = note.text;
            item.checked = true;
            await DatabaseService.instance.updateMaterial(item);
            if (mounted) Navigator.pop(context);
          },
          child: const Text('Simpan Hasil Opname'),
        ),
      ]),
    );
  }
}
