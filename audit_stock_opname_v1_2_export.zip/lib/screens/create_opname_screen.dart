import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/stock_opname.dart';
import '../services/database_service.dart';
import 'scan_mb52_screen.dart';

class CreateOpnameScreen extends StatefulWidget {
  const CreateOpnameScreen({super.key});
  @override
  State<CreateOpnameScreen> createState() => _CreateOpnameScreenState();
}

class _CreateOpnameScreenState extends State<CreateOpnameScreen> {
  final formKey = GlobalKey<FormState>();
  final name = TextEditingController();
  final location = TextEditingController();
  final sloc = TextEditingController();
  final auditor = TextEditingController();
  String date = DateFormat('yyyy-MM-dd').format(DateTime.now());

  @override
  Widget build(BuildContext context) {
    InputDecoration deco(String label) => InputDecoration(labelText: label, border: const OutlineInputBorder());
    return Scaffold(
      appBar: AppBar(title: const Text('Buat Stock Opname')),
      body: Form(
        key: formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            TextFormField(controller: name, decoration: deco('Nama Kegiatan'), validator: (v) => v!.isEmpty ? 'Wajib diisi' : null),
            const SizedBox(height: 12),
            TextFormField(controller: location, decoration: deco('Lokasi')),
            const SizedBox(height: 12),
            TextFormField(controller: sloc, decoration: deco('Storage Location')),
            const SizedBox(height: 12),
            TextFormField(controller: auditor, decoration: deco('Nama Auditor')),
            const SizedBox(height: 12),
            ListTile(
              title: const Text('Tanggal Opname'),
              subtitle: Text(date),
              trailing: const Icon(Icons.calendar_month),
              onTap: () async {
                final d = await showDatePicker(context: context, firstDate: DateTime(2020), lastDate: DateTime(2100), initialDate: DateTime.parse(date));
                if (d != null) setState(() => date = DateFormat('yyyy-MM-dd').format(d));
              },
            ),
            const SizedBox(height: 20),
            FilledButton.icon(
              icon: const Icon(Icons.camera_alt),
              label: const Text('Simpan & Scan MB52'),
              onPressed: () async {
                if (!formKey.currentState!.validate()) return;
                final opname = StockOpname(
                  activityName: name.text,
                  location: location.text,
                  sloc: sloc.text,
                  date: date,
                  auditor: auditor.text,
                );
                final id = await DatabaseService.instance.createOpname(opname);
                opname.id = id;
                if (!mounted) return;
                Navigator.pushReplacement(context,
                  MaterialPageRoute(builder: (_) => ScanMb52Screen(opname: opname)));
              },
            ),
          ],
        ),
      ),
    );
  }
}
