import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../models/stock_opname.dart';
import '../models/material_item.dart';
import '../services/ocr_service.dart';
import '../services/database_service.dart';
import 'material_list_screen.dart';

class ScanMb52Screen extends StatefulWidget {
  final StockOpname opname;
  const ScanMb52Screen({super.key, required this.opname});
  @override
  State<ScanMb52Screen> createState() => _ScanMb52ScreenState();
}

class _ScanMb52ScreenState extends State<ScanMb52Screen> {
  bool loading = false;
  final scannedItems = <MaterialItem>[];

  Future<void> scan() async {
    final picker = ImagePicker();
    final image = await picker.pickImage(source: ImageSource.camera, imageQuality: 95);
    if (image == null) return;
    setState(() => loading = true);
    try {
      final service = OcrService();
      final text = await service.extractText(File(image.path));
      final items = service.parseMb52(text);
      for (final item in items) {
        if (!scannedItems.any((x) => x.materialNumber == item.materialNumber)) {
          scannedItems.add(item);
        }
      }
      if (!mounted) return;
      await Navigator.push(context, MaterialPageRoute(
        builder: (_) => VerificationScreen(
          opname: widget.opname,
          items: scannedItems,
          rawText: text,
        ),
      ));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('OCR gagal: $e')),
      );
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Scan MB52')),
    body: Center(
      child: loading ? const CircularProgressIndicator() : Padding(
        padding: const EdgeInsets.all(24),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.document_scanner, size: 72),
          const SizedBox(height: 16),
          Text(
            'Foto layar MB52. Anda dapat melakukan scan beberapa halaman. '
            'Nomor material duplikat akan diabaikan.',
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 24),
          FilledButton.icon(
            onPressed: scan,
            icon: const Icon(Icons.camera_alt),
            label: const Text('Ambil Foto MB52'),
          ),
          const SizedBox(height: 8),
          TextButton(
            onPressed: () => Navigator.pushReplacement(context,
              MaterialPageRoute(builder: (_) => MaterialListScreen(opname: widget.opname))),
            child: const Text('Lewati Scan / Input Manual'),
          ),
        ]),
      ),
    ),
  );
}

class VerificationScreen extends StatefulWidget {
  final StockOpname opname;
  final List<MaterialItem> items;
  final String rawText;
  const VerificationScreen({
    super.key,
    required this.opname,
    required this.items,
    required this.rawText,
  });
  @override
  State<VerificationScreen> createState() => _VerificationScreenState();
}

class _VerificationScreenState extends State<VerificationScreen> {
  late List<MaterialItem> items;

  @override
  void initState() {
    super.initState();
    items = List.from(widget.items);
  }

  Future<void> _edit({MaterialItem? item, int? index}) async {
    final material = TextEditingController(text: item?.materialNumber ?? '');
    final stock = TextEditingController(text: item?.unrestrictedStock.toString() ?? '');
    final unit = TextEditingController(text: item?.unit ?? '');
    final result = await showDialog<MaterialItem>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(item == null ? 'Tambah Material' : 'Edit Material'),
        content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: material, decoration: const InputDecoration(labelText: 'Nomor Material')),
          TextField(
            controller: stock,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: const InputDecoration(labelText: 'Unrestricted Stock'),
          ),
          TextField(controller: unit, decoration: const InputDecoration(labelText: 'Base Unit of Measure')),
        ])),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Batal')),
          FilledButton(
            onPressed: () {
              final number = material.text.trim();
              final value = double.tryParse(stock.text.trim().replaceAll(',', '.'));
              if (number.isEmpty || value == null || unit.text.trim().isEmpty) return;
              Navigator.pop(context, MaterialItem(
                materialNumber: number,
                unrestrictedStock: value,
                unit: unit.text.trim(),
              ));
            },
            child: const Text('Simpan'),
          )
        ],
      ),
    );
    if (result == null) return;
    if (items.any((x) => x.materialNumber == result.materialNumber && x != item)) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Nomor material sudah ada.')),
      );
      return;
    }
    setState(() {
      if (item == null) {
        items.add(result);
      } else {
        items[index!] = result;
      }
    });
  }

  Future<void> save() async {
    final existing = await DatabaseService.instance.getMaterials(widget.opname.id!);
    final existingNumbers = existing.map((e) => e.materialNumber).toSet();
    for (final x in items) {
      if (!existingNumbers.contains(x.materialNumber)) {
        x.opnameId = widget.opname.id;
        await DatabaseService.instance.insertMaterial(x);
      }
    }
    if (!mounted) return;
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (_) => MaterialListScreen(opname: widget.opname)),
      (route) => route.isFirst,
    );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: Text('Verifikasi OCR (${items.length})'),
      actions: [IconButton(onPressed: () => _edit(), icon: const Icon(Icons.add))],
    ),
    body: Column(children: [
      Expanded(
        child: items.isEmpty
          ? const Center(child: Padding(
              padding: EdgeInsets.all(24),
              child: Text('Belum ada material. Tekan tombol + untuk input manual.'),
            ))
          : ListView.builder(
              itemCount: items.length,
              itemBuilder: (_, i) {
                final x = items[i];
                return Card(
                  child: ListTile(
                    title: Text(x.materialNumber),
                    subtitle: Text('${x.unrestrictedStock} ${x.unit}'),
                    onTap: () => _edit(item: x, index: i),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete_outline),
                      onPressed: () => setState(() => items.removeAt(i)),
                    ),
                  ),
                );
              },
            ),
      ),
      Padding(
        padding: const EdgeInsets.all(16),
        child: FilledButton.icon(
          onPressed: items.isEmpty ? null : save,
          icon: const Icon(Icons.save),
          label: const Text('Konfirmasi & Simpan'),
        ),
      ),
    ]),
  );
}
