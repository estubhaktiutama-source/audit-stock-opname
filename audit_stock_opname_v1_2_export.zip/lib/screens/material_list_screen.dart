import 'package:flutter/material.dart';
import '../models/stock_opname.dart';
import '../models/material_item.dart';
import '../services/database_service.dart';
import 'material_detail_screen.dart';
import 'summary_screen.dart';

class MaterialListScreen extends StatefulWidget {
  final StockOpname opname;
  const MaterialListScreen({super.key, required this.opname});
  @override
  State<MaterialListScreen> createState() => _MaterialListScreenState();
}

class _MaterialListScreenState extends State<MaterialListScreen> {
  List<MaterialItem> items = [];
  String query = '';

  @override
  void initState() { super.initState(); load(); }

  Future<void> load() async {
    items = await DatabaseService.instance.getMaterials(widget.opname.id!);
    if (mounted) setState(() {});
  }

  Future<void> addManual() async {
    final number = TextEditingController();
    final stock = TextEditingController();
    final unit = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Input Material Manual'),
        content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: number, decoration: const InputDecoration(labelText: 'Nomor Material')),
          TextField(controller: stock, keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: const InputDecoration(labelText: 'Unrestricted Stock')),
          TextField(controller: unit, decoration: const InputDecoration(labelText: 'Base Unit of Measure')),
        ])),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Simpan')),
        ],
      ),
    );
    if (ok != true) return;
    final value = double.tryParse(stock.text.trim().replaceAll(',', '.'));
    if (number.text.trim().isEmpty || value == null || unit.text.trim().isEmpty) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Data material belum valid.')),
      );
      return;
    }
    if (items.any((e) => e.materialNumber == number.text.trim())) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Nomor material sudah ada.')),
      );
      return;
    }
    await DatabaseService.instance.insertMaterial(MaterialItem(
      opnameId: widget.opname.id,
      materialNumber: number.text.trim(),
      unrestrictedStock: value,
      unit: unit.text.trim(),
    ));
    load();
  }

  String status(MaterialItem x) {
    if (!x.checked) return 'Belum';
    if (x.difference == 0) return 'Sesuai';
    return x.difference > 0 ? 'Plus' : 'Minus';
  }

  IconData statusIcon(MaterialItem x) {
    if (!x.checked) return Icons.schedule;
    if (x.difference == 0) return Icons.check_circle;
    return x.difference > 0 ? Icons.arrow_upward : Icons.arrow_downward;
  }

  @override
  Widget build(BuildContext context) {
    final filtered = items.where((x) => x.materialNumber.toLowerCase().contains(query.toLowerCase())).toList();
    final checked = items.where((x) => x.checked).length;
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.opname.activityName),
        actions: [
          IconButton(icon: const Icon(Icons.analytics_outlined),
            onPressed: () => Navigator.push(context,
              MaterialPageRoute(builder: (_) => SummaryScreen(opname: widget.opname)))),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: addManual,
        icon: const Icon(Icons.add),
        label: const Text('Material'),
      ),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.all(12),
          child: Column(children: [
            LinearProgressIndicator(value: items.isEmpty ? 0 : checked / items.length),
            const SizedBox(height: 8),
            Text('Progress: $checked / ${items.length}'),
            const SizedBox(height: 10),
            TextField(
              decoration: const InputDecoration(
                prefixIcon: Icon(Icons.search),
                hintText: 'Cari nomor material',
                border: OutlineInputBorder(),
              ),
              onChanged: (v) => setState(() => query = v),
            ),
          ]),
        ),
        Expanded(
          child: items.isEmpty
            ? const Center(child: Text('Belum ada material.'))
            : ListView.builder(
                itemCount: filtered.length,
                itemBuilder: (_, i) {
                  final x = filtered[i];
                  return Card(child: ListTile(
                    leading: Icon(statusIcon(x)),
                    title: Text(x.materialNumber),
                    subtitle: Text('MB52: ${x.unrestrictedStock} ${x.unit}\nStatus: ${status(x)}'),
                    isThreeLine: true,
                    trailing: x.checked
                      ? Text('${x.difference >= 0 ? '+' : ''}${x.difference}')
                      : null,
                    onTap: () async {
                      await Navigator.push(context,
                        MaterialPageRoute(builder: (_) => MaterialDetailScreen(item: x)));
                      load();
                    },
                  ));
                },
              ),
        ),
      ]),
    );
  }
}
