import 'package:flutter/material.dart';
import '../models/stock_opname.dart';
import '../services/database_service.dart';
import 'create_opname_screen.dart';
import 'material_list_screen.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});
  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  late Future<List<StockOpname>> _future;

  @override
  void initState() {
    super.initState();
    _future = DatabaseService.instance.getOpnames();
  }

  void _refresh() => setState(() {
    _future = DatabaseService.instance.getOpnames();
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Audit Stock Opname')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          await Navigator.push(context,
            MaterialPageRoute(builder: (_) => const CreateOpnameScreen()));
          _refresh();
        },
        icon: const Icon(Icons.add),
        label: const Text('Buat Opname'),
      ),
      body: FutureBuilder<List<StockOpname>>(
        future: _future,
        builder: (context, snapshot) {
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          final data = snapshot.data!;
          if (data.isEmpty) {
            return const Center(child: Text('Belum ada kegiatan stock opname.'));
          }
          return ListView.builder(
            padding: const EdgeInsets.all(12),
            itemCount: data.length,
            itemBuilder: (_, i) {
              final x = data[i];
              return Card(
                child: ListTile(
                  leading: const CircleAvatar(child: Icon(Icons.inventory_2)),
                  title: Text(x.activityName),
                  subtitle: Text('${x.location} • SLOC: ${x.sloc}\n${x.date} • ${x.auditor}'),
                  isThreeLine: true,
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => Navigator.push(context,
                    MaterialPageRoute(builder: (_) => MaterialListScreen(opname: x))),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
