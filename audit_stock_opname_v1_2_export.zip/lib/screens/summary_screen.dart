import 'package:flutter/material.dart';
import '../models/stock_opname.dart';
import '../models/material_item.dart';
import '../services/database_service.dart';
import '../services/export_service.dart';

class SummaryScreen extends StatefulWidget {
  final StockOpname opname;
  const SummaryScreen({super.key, required this.opname});
  @override
  State<SummaryScreen> createState() => _SummaryScreenState();
}

class _SummaryScreenState extends State<SummaryScreen> {
  bool exporting = false;

  Future<void> _export(List<MaterialItem> items, bool excel) async {
    setState(() => exporting = true);
    try {
      final service = ExportService();
      final file = excel
          ? await service.exportExcel(widget.opname, items)
          : await service.exportCsv(widget.opname, items);
      if (!mounted) return;
      await service.shareFile(
        file,
        'Hasil Audit Stock Opname - ${widget.opname.activityName}',
      );
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Export gagal: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => exporting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Hasil Stock Opname')),
      body: FutureBuilder<List<MaterialItem>>(
        future: DatabaseService.instance.getMaterials(widget.opname.id!),
        builder: (_, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final x = snapshot.data!;
          final checked = x.where((e) => e.checked).toList();
          final match = checked.where((e) => e.difference == 0).length;
          final plus = checked.where((e) => e.difference > 0).length;
          final minus = checked.where((e) => e.difference < 0).length;

          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Text(widget.opname.activityName,
                  style: Theme.of(context).textTheme.headlineSmall),
              const SizedBox(height: 20),
              _card('Total Material', x.length, Icons.inventory_2),
              _card('Sudah Diperiksa', checked.length, Icons.fact_check),
              _card('Sesuai', match, Icons.check_circle),
              _card('Selisih Plus', plus, Icons.arrow_upward),
              _card('Selisih Minus', minus, Icons.arrow_downward),
              const SizedBox(height: 24),
              const Text('EXPORT HASIL',
                  style: TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              FilledButton.icon(
                onPressed: exporting ? null : () => _export(x, true),
                icon: const Icon(Icons.table_view),
                label: const Text('Export & Kirim Excel (.xlsx)'),
              ),
              const SizedBox(height: 10),
              OutlinedButton.icon(
                onPressed: exporting ? null : () => _export(x, false),
                icon: const Icon(Icons.description),
                label: const Text('Export & Kirim CSV (.csv)'),
              ),
              if (exporting) ...[
                const SizedBox(height: 16),
                const Center(child: CircularProgressIndicator()),
                const SizedBox(height: 8),
                const Center(child: Text('Menyiapkan file...')),
              ],
              const SizedBox(height: 12),
              const Text(
                'Setelah export, gunakan menu Share Android untuk mengirim '
                'file ke Email, Google Drive, OneDrive, WhatsApp, Bluetooth, '
                'atau Quick Share ke laptop.',
                style: TextStyle(fontSize: 12),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _card(String label, int value, IconData icon) => Card(
    child: ListTile(
      leading: Icon(icon),
      title: Text(label),
      trailing: Text(
        '$value',
        style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
      ),
    ),
  );
}
