# Audit Stock Opname V1.2

## Fitur V1.2
- Semua fitur V1.1
- Export Excel (.xlsx)
- Export CSV (.csv)
- Header informasi audit
- Detail seluruh material
- Expected Stock dan Selisih
- Status material
- Ringkasan hasil
- Share file menggunakan Android Share Sheet

## Alur Export
Selesaikan Opname
-> Hasil Stock Opname
-> Export Excel / CSV
-> Android Share
-> Email / Drive / OneDrive / Quick Share / Bluetooth
-> Laptop

## Build
1. Install Flutter SDK dan Android SDK.
2. Dari folder proyek:
   flutter create .
   flutter pub get
   flutter build apk --release

APK:
build/app/outputs/flutter-apk/app-release.apk

## Catatan
Project source ini perlu diuji dengan versi Flutter dan Android SDK yang digunakan.
OCR MB52 masih menggunakan parser generik dan hasil scan harus diverifikasi.
